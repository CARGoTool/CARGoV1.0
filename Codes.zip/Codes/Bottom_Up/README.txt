							Bottom-Up Approach
							-----------------
--structure.h 				---SAi* Nets Structure

--LEX.H 				---Token identifier

--mainfunc.c  				---Executes different modules
 
--filtoken.c  				---Breaks the content of the input goal model into tokens

--recognizetoken.c  			---Sets a unique code-number to each token and identifies keywords and variables

--modelelement.c   			---Identifies actors and root and nodes of the tree under each actor

--create_datastructure.c  		---Builds SAi* Nets with the elements found in the given goal model

--semantic_reconciliation.c 		---Computes CE of each node by traversing SAi* network in bottom-up approach

--Conflict_Check.c 			---Traverses SAi* network in Bottom-Up approach and generates the conflict list

--conflict_display.c 			---Logs conflict details

--display.c 				---Logs SAi* Nets

--Entailment_resolution.c 		---Extracts node from the conflict list and performs Entailment Resolution Algorithm(ERA)

--remove_ce.c  				---Removes CE of a node while Entailment Resolution is being performed

--remove_null_IE.c  			---Removes nodes having null IE after ERA

--Consistency_Conflict_resolution.c  	---Extracts node from the conflict list and performs Consistency conflict Resolution Algorithm(CRA)

--nullCE.c 				---Removes CEs of each node before initiating the next iteration of Semantic Reconciliation and Conflict Resolution

--create_output_text.c  		---Generates output goal model

--otherFunctions.c      		---Checks stopping condition of Semantic Reconciliation and Conflict Resolution

